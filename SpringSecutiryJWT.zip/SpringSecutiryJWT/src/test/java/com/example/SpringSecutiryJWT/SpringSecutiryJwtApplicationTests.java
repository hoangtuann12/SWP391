package com.example.SpringSecutiryJWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecutiryJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
