package com.example.SpringSecutiryJWT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecutiryJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecutiryJwtApplication.class, args);
	}

}
